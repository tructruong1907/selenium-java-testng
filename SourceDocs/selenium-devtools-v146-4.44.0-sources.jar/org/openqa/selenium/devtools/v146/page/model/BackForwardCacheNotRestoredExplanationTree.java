package org.openqa.selenium.devtools.v146.page.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class BackForwardCacheNotRestoredExplanationTree {

    private final java.lang.String url;

    private final java.util.List<org.openqa.selenium.devtools.v146.page.model.BackForwardCacheNotRestoredExplanation> explanations;

    private final java.util.List<org.openqa.selenium.devtools.v146.page.model.BackForwardCacheNotRestoredExplanationTree> children;

    public BackForwardCacheNotRestoredExplanationTree(java.lang.String url, java.util.List<org.openqa.selenium.devtools.v146.page.model.BackForwardCacheNotRestoredExplanation> explanations, java.util.List<org.openqa.selenium.devtools.v146.page.model.BackForwardCacheNotRestoredExplanationTree> children) {
        this.url = java.util.Objects.requireNonNull(url, "url is required");
        this.explanations = java.util.Objects.requireNonNull(explanations, "explanations is required");
        this.children = java.util.Objects.requireNonNull(children, "children is required");
    }

    /**
     * URL of each frame
     */
    public java.lang.String getUrl() {
        return url;
    }

    /**
     * Not restored reasons of each frame
     */
    public java.util.List<org.openqa.selenium.devtools.v146.page.model.BackForwardCacheNotRestoredExplanation> getExplanations() {
        return explanations;
    }

    /**
     * Array of children frame
     */
    public java.util.List<org.openqa.selenium.devtools.v146.page.model.BackForwardCacheNotRestoredExplanationTree> getChildren() {
        return children;
    }

    private static BackForwardCacheNotRestoredExplanationTree fromJson(JsonInput input) {
        java.lang.String url = null;
        java.util.List<org.openqa.selenium.devtools.v146.page.model.BackForwardCacheNotRestoredExplanation> explanations = null;
        java.util.List<org.openqa.selenium.devtools.v146.page.model.BackForwardCacheNotRestoredExplanationTree> children = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "url":
                    url = input.nextString();
                    break;
                case "explanations":
                    explanations = input.readArray(org.openqa.selenium.devtools.v146.page.model.BackForwardCacheNotRestoredExplanation.class);
                    break;
                case "children":
                    children = input.readArray(org.openqa.selenium.devtools.v146.page.model.BackForwardCacheNotRestoredExplanationTree.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new BackForwardCacheNotRestoredExplanationTree(url, explanations, children);
    }
}
