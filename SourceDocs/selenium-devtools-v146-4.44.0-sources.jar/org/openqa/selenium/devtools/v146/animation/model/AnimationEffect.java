package org.openqa.selenium.devtools.v146.animation.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * AnimationEffect instance
 */
public class AnimationEffect {

    private final java.lang.Number delay;

    private final java.lang.Number endDelay;

    private final java.lang.Number iterationStart;

    private final java.util.Optional<java.lang.Number> iterations;

    private final java.lang.Number duration;

    private final java.lang.String direction;

    private final java.lang.String fill;

    private final java.util.Optional<org.openqa.selenium.devtools.v146.dom.model.BackendNodeId> backendNodeId;

    private final java.util.Optional<org.openqa.selenium.devtools.v146.animation.model.KeyframesRule> keyframesRule;

    private final java.lang.String easing;

    public AnimationEffect(java.lang.Number delay, java.lang.Number endDelay, java.lang.Number iterationStart, java.util.Optional<java.lang.Number> iterations, java.lang.Number duration, java.lang.String direction, java.lang.String fill, java.util.Optional<org.openqa.selenium.devtools.v146.dom.model.BackendNodeId> backendNodeId, java.util.Optional<org.openqa.selenium.devtools.v146.animation.model.KeyframesRule> keyframesRule, java.lang.String easing) {
        this.delay = java.util.Objects.requireNonNull(delay, "delay is required");
        this.endDelay = java.util.Objects.requireNonNull(endDelay, "endDelay is required");
        this.iterationStart = java.util.Objects.requireNonNull(iterationStart, "iterationStart is required");
        this.iterations = iterations;
        this.duration = java.util.Objects.requireNonNull(duration, "duration is required");
        this.direction = java.util.Objects.requireNonNull(direction, "direction is required");
        this.fill = java.util.Objects.requireNonNull(fill, "fill is required");
        this.backendNodeId = backendNodeId;
        this.keyframesRule = keyframesRule;
        this.easing = java.util.Objects.requireNonNull(easing, "easing is required");
    }

    /**
     * `AnimationEffect`'s delay.
     */
    public java.lang.Number getDelay() {
        return delay;
    }

    /**
     * `AnimationEffect`'s end delay.
     */
    public java.lang.Number getEndDelay() {
        return endDelay;
    }

    /**
     * `AnimationEffect`'s iteration start.
     */
    public java.lang.Number getIterationStart() {
        return iterationStart;
    }

    /**
     * `AnimationEffect`'s iterations. Omitted if the value is infinite.
     */
    public java.util.Optional<java.lang.Number> getIterations() {
        return iterations;
    }

    /**
     * `AnimationEffect`'s iteration duration.
     * Milliseconds for time based animations and
     * percentage [0 - 100] for scroll driven animations
     * (i.e. when viewOrScrollTimeline exists).
     */
    public java.lang.Number getDuration() {
        return duration;
    }

    /**
     * `AnimationEffect`'s playback direction.
     */
    public java.lang.String getDirection() {
        return direction;
    }

    /**
     * `AnimationEffect`'s fill mode.
     */
    public java.lang.String getFill() {
        return fill;
    }

    /**
     * `AnimationEffect`'s target node.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v146.dom.model.BackendNodeId> getBackendNodeId() {
        return backendNodeId;
    }

    /**
     * `AnimationEffect`'s keyframes.
     */
    public java.util.Optional<org.openqa.selenium.devtools.v146.animation.model.KeyframesRule> getKeyframesRule() {
        return keyframesRule;
    }

    /**
     * `AnimationEffect`'s timing function.
     */
    public java.lang.String getEasing() {
        return easing;
    }

    private static AnimationEffect fromJson(JsonInput input) {
        java.lang.Number delay = 0;
        java.lang.Number endDelay = 0;
        java.lang.Number iterationStart = 0;
        java.util.Optional<java.lang.Number> iterations = java.util.Optional.empty();
        java.lang.Number duration = 0;
        java.lang.String direction = null;
        java.lang.String fill = null;
        java.util.Optional<org.openqa.selenium.devtools.v146.dom.model.BackendNodeId> backendNodeId = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v146.animation.model.KeyframesRule> keyframesRule = java.util.Optional.empty();
        java.lang.String easing = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "delay":
                    delay = input.nextNumber();
                    break;
                case "endDelay":
                    endDelay = input.nextNumber();
                    break;
                case "iterationStart":
                    iterationStart = input.nextNumber();
                    break;
                case "iterations":
                    iterations = java.util.Optional.ofNullable(input.nextNumber());
                    break;
                case "duration":
                    duration = input.nextNumber();
                    break;
                case "direction":
                    direction = input.nextString();
                    break;
                case "fill":
                    fill = input.nextString();
                    break;
                case "backendNodeId":
                    backendNodeId = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v146.dom.model.BackendNodeId.class));
                    break;
                case "keyframesRule":
                    keyframesRule = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v146.animation.model.KeyframesRule.class));
                    break;
                case "easing":
                    easing = input.nextString();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AnimationEffect(delay, endDelay, iterationStart, iterations, duration, direction, fill, backendNodeId, keyframesRule, easing);
    }
}
