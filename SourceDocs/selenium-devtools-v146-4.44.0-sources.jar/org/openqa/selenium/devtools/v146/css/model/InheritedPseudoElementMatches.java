package org.openqa.selenium.devtools.v146.css.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Inherited pseudo element matches from pseudos of an ancestor node.
 */
public class InheritedPseudoElementMatches {

    private final java.util.List<org.openqa.selenium.devtools.v146.css.model.PseudoElementMatches> pseudoElements;

    public InheritedPseudoElementMatches(java.util.List<org.openqa.selenium.devtools.v146.css.model.PseudoElementMatches> pseudoElements) {
        this.pseudoElements = java.util.Objects.requireNonNull(pseudoElements, "pseudoElements is required");
    }

    /**
     * Matches of pseudo styles from the pseudos of an ancestor node.
     */
    public java.util.List<org.openqa.selenium.devtools.v146.css.model.PseudoElementMatches> getPseudoElements() {
        return pseudoElements;
    }

    private static InheritedPseudoElementMatches fromJson(JsonInput input) {
        java.util.List<org.openqa.selenium.devtools.v146.css.model.PseudoElementMatches> pseudoElements = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "pseudoElements":
                    pseudoElements = input.readArray(org.openqa.selenium.devtools.v146.css.model.PseudoElementMatches.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new InheritedPseudoElementMatches(pseudoElements);
    }
}
