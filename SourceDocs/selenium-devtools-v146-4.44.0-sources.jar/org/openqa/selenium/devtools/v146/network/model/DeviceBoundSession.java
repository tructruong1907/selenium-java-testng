package org.openqa.selenium.devtools.v146.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * A device bound session.
 */
@org.openqa.selenium.Beta()
public class DeviceBoundSession {

    private final org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionKey key;

    private final java.lang.String refreshUrl;

    private final org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionInclusionRules inclusionRules;

    private final java.util.List<org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionCookieCraving> cookieCravings;

    private final org.openqa.selenium.devtools.v146.network.model.TimeSinceEpoch expiryDate;

    private final java.util.Optional<java.lang.String> cachedChallenge;

    private final java.util.List<java.lang.String> allowedRefreshInitiators;

    public DeviceBoundSession(org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionKey key, java.lang.String refreshUrl, org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionInclusionRules inclusionRules, java.util.List<org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionCookieCraving> cookieCravings, org.openqa.selenium.devtools.v146.network.model.TimeSinceEpoch expiryDate, java.util.Optional<java.lang.String> cachedChallenge, java.util.List<java.lang.String> allowedRefreshInitiators) {
        this.key = java.util.Objects.requireNonNull(key, "key is required");
        this.refreshUrl = java.util.Objects.requireNonNull(refreshUrl, "refreshUrl is required");
        this.inclusionRules = java.util.Objects.requireNonNull(inclusionRules, "inclusionRules is required");
        this.cookieCravings = java.util.Objects.requireNonNull(cookieCravings, "cookieCravings is required");
        this.expiryDate = java.util.Objects.requireNonNull(expiryDate, "expiryDate is required");
        this.cachedChallenge = cachedChallenge;
        this.allowedRefreshInitiators = java.util.Objects.requireNonNull(allowedRefreshInitiators, "allowedRefreshInitiators is required");
    }

    /**
     * The site and session ID of the session.
     */
    public org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionKey getKey() {
        return key;
    }

    /**
     * See comments on `net::device_bound_sessions::Session::refresh_url_`.
     */
    public java.lang.String getRefreshUrl() {
        return refreshUrl;
    }

    /**
     * See comments on `net::device_bound_sessions::Session::inclusion_rules_`.
     */
    public org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionInclusionRules getInclusionRules() {
        return inclusionRules;
    }

    /**
     * See comments on `net::device_bound_sessions::Session::cookie_cravings_`.
     */
    public java.util.List<org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionCookieCraving> getCookieCravings() {
        return cookieCravings;
    }

    /**
     * See comments on `net::device_bound_sessions::Session::expiry_date_`.
     */
    public org.openqa.selenium.devtools.v146.network.model.TimeSinceEpoch getExpiryDate() {
        return expiryDate;
    }

    /**
     * See comments on `net::device_bound_sessions::Session::cached_challenge__`.
     */
    public java.util.Optional<java.lang.String> getCachedChallenge() {
        return cachedChallenge;
    }

    /**
     * See comments on `net::device_bound_sessions::Session::allowed_refresh_initiators_`.
     */
    public java.util.List<java.lang.String> getAllowedRefreshInitiators() {
        return allowedRefreshInitiators;
    }

    private static DeviceBoundSession fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionKey key = null;
        java.lang.String refreshUrl = null;
        org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionInclusionRules inclusionRules = null;
        java.util.List<org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionCookieCraving> cookieCravings = null;
        org.openqa.selenium.devtools.v146.network.model.TimeSinceEpoch expiryDate = null;
        java.util.Optional<java.lang.String> cachedChallenge = java.util.Optional.empty();
        java.util.List<java.lang.String> allowedRefreshInitiators = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "key":
                    key = input.read(org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionKey.class);
                    break;
                case "refreshUrl":
                    refreshUrl = input.nextString();
                    break;
                case "inclusionRules":
                    inclusionRules = input.read(org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionInclusionRules.class);
                    break;
                case "cookieCravings":
                    cookieCravings = input.readArray(org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionCookieCraving.class);
                    break;
                case "expiryDate":
                    expiryDate = input.read(org.openqa.selenium.devtools.v146.network.model.TimeSinceEpoch.class);
                    break;
                case "cachedChallenge":
                    cachedChallenge = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "allowedRefreshInitiators":
                    allowedRefreshInitiators = input.readArray(java.lang.String.class);
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new DeviceBoundSession(key, refreshUrl, inclusionRules, cookieCravings, expiryDate, cachedChallenge, allowedRefreshInitiators);
    }
}
