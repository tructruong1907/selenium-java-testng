package org.openqa.selenium.devtools.v146.network;

import org.openqa.selenium.Beta;
import org.openqa.selenium.devtools.Command;
import org.openqa.selenium.devtools.Event;
import org.openqa.selenium.devtools.ConverterFunctions;
import java.util.Map;
import java.util.LinkedHashMap;
import org.openqa.selenium.json.JsonInput;

/**
 * Network domain allows tracking network activities of the page. It exposes information about http,
 * file, data and other requests and responses, their headers, bodies, timing, etc.
 */
public class Network {

    /**
     * Sets a list of content encodings that will be accepted. Empty list means no encoding is accepted.
     */
    @Beta()
    public static Command<Void> setAcceptedEncodings(java.util.List<org.openqa.selenium.devtools.v146.network.model.ContentEncoding> encodings) {
        java.util.Objects.requireNonNull(encodings, "encodings is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("encodings", encodings);
        return new Command<>("Network.setAcceptedEncodings", Map.copyOf(params));
    }

    /**
     * Clears accepted encodings set by setAcceptedEncodings
     */
    @Beta()
    public static Command<Void> clearAcceptedEncodingsOverride() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Network.clearAcceptedEncodingsOverride", Map.copyOf(params));
    }

    /**
     * Tells whether clearing browser cache is supported.
     */
    @Deprecated()
    public static Command<java.lang.Boolean> canClearBrowserCache() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Network.canClearBrowserCache", Map.copyOf(params), ConverterFunctions.map("result", java.lang.Boolean.class));
    }

    /**
     * Tells whether clearing browser cookies is supported.
     */
    @Deprecated()
    public static Command<java.lang.Boolean> canClearBrowserCookies() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Network.canClearBrowserCookies", Map.copyOf(params), ConverterFunctions.map("result", java.lang.Boolean.class));
    }

    /**
     * Tells whether emulation of network conditions is supported.
     */
    @Deprecated()
    public static Command<java.lang.Boolean> canEmulateNetworkConditions() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Network.canEmulateNetworkConditions", Map.copyOf(params), ConverterFunctions.map("result", java.lang.Boolean.class));
    }

    /**
     * Clears browser cache.
     */
    public static Command<Void> clearBrowserCache() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Network.clearBrowserCache", Map.copyOf(params));
    }

    /**
     * Clears browser cookies.
     */
    public static Command<Void> clearBrowserCookies() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Network.clearBrowserCookies", Map.copyOf(params));
    }

    /**
     * Response to Network.requestIntercepted which either modifies the request to continue with any
     * modifications, or blocks it, or completes it with the provided response bytes. If a network
     * fetch occurs as a result which encounters a redirect an additional Network.requestIntercepted
     * event will be sent with the same InterceptionId.
     * Deprecated, use Fetch.continueRequest, Fetch.fulfillRequest and Fetch.failRequest instead.
     */
    @Beta()
    @Deprecated()
    public static Command<Void> continueInterceptedRequest(org.openqa.selenium.devtools.v146.network.model.InterceptionId interceptionId, java.util.Optional<org.openqa.selenium.devtools.v146.network.model.ErrorReason> errorReason, java.util.Optional<java.lang.String> rawResponse, java.util.Optional<java.lang.String> url, java.util.Optional<java.lang.String> method, java.util.Optional<java.lang.String> postData, java.util.Optional<org.openqa.selenium.devtools.v146.network.model.Headers> headers, java.util.Optional<org.openqa.selenium.devtools.v146.network.model.AuthChallengeResponse> authChallengeResponse) {
        java.util.Objects.requireNonNull(interceptionId, "interceptionId is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("interceptionId", interceptionId);
        errorReason.ifPresent(p -> params.put("errorReason", p));
        rawResponse.ifPresent(p -> params.put("rawResponse", p));
        url.ifPresent(p -> params.put("url", p));
        method.ifPresent(p -> params.put("method", p));
        postData.ifPresent(p -> params.put("postData", p));
        headers.ifPresent(p -> params.put("headers", p));
        authChallengeResponse.ifPresent(p -> params.put("authChallengeResponse", p));
        return new Command<>("Network.continueInterceptedRequest", Map.copyOf(params));
    }

    /**
     * Deletes browser cookies with matching name and url or domain/path/partitionKey pair.
     */
    public static Command<Void> deleteCookies(java.lang.String name, java.util.Optional<java.lang.String> url, java.util.Optional<java.lang.String> domain, java.util.Optional<java.lang.String> path, java.util.Optional<org.openqa.selenium.devtools.v146.network.model.CookiePartitionKey> partitionKey) {
        java.util.Objects.requireNonNull(name, "name is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("name", name);
        url.ifPresent(p -> params.put("url", p));
        domain.ifPresent(p -> params.put("domain", p));
        path.ifPresent(p -> params.put("path", p));
        partitionKey.ifPresent(p -> params.put("partitionKey", p));
        return new Command<>("Network.deleteCookies", Map.copyOf(params));
    }

    /**
     * Disables network tracking, prevents network events from being sent to the client.
     */
    public static Command<Void> disable() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Network.disable", Map.copyOf(params));
    }

    /**
     * Activates emulation of network conditions. This command is deprecated in favor of the emulateNetworkConditionsByRule
     * and overrideNetworkState commands, which can be used together to the same effect.
     */
    @Deprecated()
    public static Command<Void> emulateNetworkConditions(java.lang.Boolean offline, java.lang.Number latency, java.lang.Number downloadThroughput, java.lang.Number uploadThroughput, java.util.Optional<org.openqa.selenium.devtools.v146.network.model.ConnectionType> connectionType, java.util.Optional<java.lang.Number> packetLoss, java.util.Optional<java.lang.Integer> packetQueueLength, java.util.Optional<java.lang.Boolean> packetReordering) {
        java.util.Objects.requireNonNull(offline, "offline is required");
        java.util.Objects.requireNonNull(latency, "latency is required");
        java.util.Objects.requireNonNull(downloadThroughput, "downloadThroughput is required");
        java.util.Objects.requireNonNull(uploadThroughput, "uploadThroughput is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("offline", offline);
        params.put("latency", latency);
        params.put("downloadThroughput", downloadThroughput);
        params.put("uploadThroughput", uploadThroughput);
        connectionType.ifPresent(p -> params.put("connectionType", p));
        packetLoss.ifPresent(p -> params.put("packetLoss", p));
        packetQueueLength.ifPresent(p -> params.put("packetQueueLength", p));
        packetReordering.ifPresent(p -> params.put("packetReordering", p));
        return new Command<>("Network.emulateNetworkConditions", Map.copyOf(params));
    }

    /**
     * Activates emulation of network conditions for individual requests using URL match patterns. Unlike the deprecated
     * Network.emulateNetworkConditions this method does not affect `navigator` state. Use Network.overrideNetworkState to
     * explicitly modify `navigator` behavior.
     */
    @Beta()
    public static Command<java.util.List<java.lang.String>> emulateNetworkConditionsByRule(java.lang.Boolean offline, java.util.List<org.openqa.selenium.devtools.v146.network.model.NetworkConditions> matchedNetworkConditions) {
        java.util.Objects.requireNonNull(offline, "offline is required");
        java.util.Objects.requireNonNull(matchedNetworkConditions, "matchedNetworkConditions is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("offline", offline);
        params.put("matchedNetworkConditions", matchedNetworkConditions);
        return new Command<>("Network.emulateNetworkConditionsByRule", Map.copyOf(params), ConverterFunctions.map("ruleIds", input -> input.readArray(java.lang.String.class)));
    }

    /**
     * Override the state of navigator.onLine and navigator.connection.
     */
    @Beta()
    public static Command<Void> overrideNetworkState(java.lang.Boolean offline, java.lang.Number latency, java.lang.Number downloadThroughput, java.lang.Number uploadThroughput, java.util.Optional<org.openqa.selenium.devtools.v146.network.model.ConnectionType> connectionType) {
        java.util.Objects.requireNonNull(offline, "offline is required");
        java.util.Objects.requireNonNull(latency, "latency is required");
        java.util.Objects.requireNonNull(downloadThroughput, "downloadThroughput is required");
        java.util.Objects.requireNonNull(uploadThroughput, "uploadThroughput is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("offline", offline);
        params.put("latency", latency);
        params.put("downloadThroughput", downloadThroughput);
        params.put("uploadThroughput", uploadThroughput);
        connectionType.ifPresent(p -> params.put("connectionType", p));
        return new Command<>("Network.overrideNetworkState", Map.copyOf(params));
    }

    /**
     * Enables network tracking, network events will now be delivered to the client.
     */
    public static Command<Void> enable(java.util.Optional<java.lang.Integer> maxTotalBufferSize, java.util.Optional<java.lang.Integer> maxResourceBufferSize, java.util.Optional<java.lang.Integer> maxPostDataSize, java.util.Optional<java.lang.Boolean> reportDirectSocketTraffic, java.util.Optional<java.lang.Boolean> enableDurableMessages) {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        maxTotalBufferSize.ifPresent(p -> params.put("maxTotalBufferSize", p));
        maxResourceBufferSize.ifPresent(p -> params.put("maxResourceBufferSize", p));
        maxPostDataSize.ifPresent(p -> params.put("maxPostDataSize", p));
        reportDirectSocketTraffic.ifPresent(p -> params.put("reportDirectSocketTraffic", p));
        enableDurableMessages.ifPresent(p -> params.put("enableDurableMessages", p));
        return new Command<>("Network.enable", Map.copyOf(params));
    }

    /**
     * Configures storing response bodies outside of renderer, so that these survive
     * a cross-process navigation.
     * If maxTotalBufferSize is not set, durable messages are disabled.
     */
    @Beta()
    public static Command<Void> configureDurableMessages(java.util.Optional<java.lang.Integer> maxTotalBufferSize, java.util.Optional<java.lang.Integer> maxResourceBufferSize) {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        maxTotalBufferSize.ifPresent(p -> params.put("maxTotalBufferSize", p));
        maxResourceBufferSize.ifPresent(p -> params.put("maxResourceBufferSize", p));
        return new Command<>("Network.configureDurableMessages", Map.copyOf(params));
    }

    /**
     * Returns all browser cookies. Depending on the backend support, will return detailed cookie
     * information in the `cookies` field.
     * Deprecated. Use Storage.getCookies instead.
     */
    @Deprecated()
    public static Command<java.util.List<org.openqa.selenium.devtools.v146.network.model.Cookie>> getAllCookies() {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        return new Command<>("Network.getAllCookies", Map.copyOf(params), ConverterFunctions.map("cookies", input -> input.readArray(org.openqa.selenium.devtools.v146.network.model.Cookie.class)));
    }

    /**
     * Returns the DER-encoded certificate.
     */
    @Beta()
    public static Command<java.util.List<java.lang.String>> getCertificate(java.lang.String origin) {
        java.util.Objects.requireNonNull(origin, "origin is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("origin", origin);
        return new Command<>("Network.getCertificate", Map.copyOf(params), ConverterFunctions.map("tableNames", input -> input.readArray(java.lang.String.class)));
    }

    /**
     * Returns all browser cookies for the current URL. Depending on the backend support, will return
     * detailed cookie information in the `cookies` field.
     */
    public static Command<java.util.List<org.openqa.selenium.devtools.v146.network.model.Cookie>> getCookies(java.util.Optional<java.util.List<java.lang.String>> urls) {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        urls.ifPresent(p -> params.put("urls", p));
        return new Command<>("Network.getCookies", Map.copyOf(params), ConverterFunctions.map("cookies", input -> input.readArray(org.openqa.selenium.devtools.v146.network.model.Cookie.class)));
    }

    public static class GetResponseBodyResponse {

        private final java.lang.String body;

        private final java.lang.Boolean base64Encoded;

        public GetResponseBodyResponse(java.lang.String body, java.lang.Boolean base64Encoded) {
            this.body = java.util.Objects.requireNonNull(body, "body is required");
            this.base64Encoded = java.util.Objects.requireNonNull(base64Encoded, "base64Encoded is required");
        }

        /**
         * Response body.
         */
        public java.lang.String getBody() {
            return body;
        }

        /**
         * True, if content was sent as base64.
         */
        public java.lang.Boolean getBase64Encoded() {
            return base64Encoded;
        }

        private static GetResponseBodyResponse fromJson(JsonInput input) {
            java.lang.String body = null;
            java.lang.Boolean base64Encoded = false;
            input.beginObject();
            while (input.hasNext()) {
                switch(input.nextName()) {
                    case "body":
                        body = input.nextString();
                        break;
                    case "base64Encoded":
                        base64Encoded = input.nextBoolean();
                        break;
                    default:
                        input.skipValue();
                        break;
                }
            }
            input.endObject();
            return new GetResponseBodyResponse(body, base64Encoded);
        }
    }

    /**
     * Returns content served for the given request.
     */
    public static Command<org.openqa.selenium.devtools.v146.network.Network.GetResponseBodyResponse> getResponseBody(org.openqa.selenium.devtools.v146.network.model.RequestId requestId) {
        java.util.Objects.requireNonNull(requestId, "requestId is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("requestId", requestId);
        return new Command<>("Network.getResponseBody", Map.copyOf(params), input -> input.read(org.openqa.selenium.devtools.v146.network.Network.GetResponseBodyResponse.class));
    }

    public static class GetRequestPostDataResponse {

        private final java.lang.String postData;

        private final java.lang.Boolean base64Encoded;

        public GetRequestPostDataResponse(java.lang.String postData, java.lang.Boolean base64Encoded) {
            this.postData = java.util.Objects.requireNonNull(postData, "postData is required");
            this.base64Encoded = java.util.Objects.requireNonNull(base64Encoded, "base64Encoded is required");
        }

        /**
         * Request body string, omitting files from multipart requests
         */
        public java.lang.String getPostData() {
            return postData;
        }

        /**
         * True, if content was sent as base64.
         */
        public java.lang.Boolean getBase64Encoded() {
            return base64Encoded;
        }

        private static GetRequestPostDataResponse fromJson(JsonInput input) {
            java.lang.String postData = null;
            java.lang.Boolean base64Encoded = false;
            input.beginObject();
            while (input.hasNext()) {
                switch(input.nextName()) {
                    case "postData":
                        postData = input.nextString();
                        break;
                    case "base64Encoded":
                        base64Encoded = input.nextBoolean();
                        break;
                    default:
                        input.skipValue();
                        break;
                }
            }
            input.endObject();
            return new GetRequestPostDataResponse(postData, base64Encoded);
        }
    }

    /**
     * Returns post data sent with the request. Returns an error when no data was sent with the request.
     */
    public static Command<org.openqa.selenium.devtools.v146.network.Network.GetRequestPostDataResponse> getRequestPostData(org.openqa.selenium.devtools.v146.network.model.RequestId requestId) {
        java.util.Objects.requireNonNull(requestId, "requestId is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("requestId", requestId);
        return new Command<>("Network.getRequestPostData", Map.copyOf(params), input -> input.read(org.openqa.selenium.devtools.v146.network.Network.GetRequestPostDataResponse.class));
    }

    public static class GetResponseBodyForInterceptionResponse {

        private final java.lang.String body;

        private final java.lang.Boolean base64Encoded;

        public GetResponseBodyForInterceptionResponse(java.lang.String body, java.lang.Boolean base64Encoded) {
            this.body = java.util.Objects.requireNonNull(body, "body is required");
            this.base64Encoded = java.util.Objects.requireNonNull(base64Encoded, "base64Encoded is required");
        }

        /**
         * Response body.
         */
        public java.lang.String getBody() {
            return body;
        }

        /**
         * True, if content was sent as base64.
         */
        public java.lang.Boolean getBase64Encoded() {
            return base64Encoded;
        }

        private static GetResponseBodyForInterceptionResponse fromJson(JsonInput input) {
            java.lang.String body = null;
            java.lang.Boolean base64Encoded = false;
            input.beginObject();
            while (input.hasNext()) {
                switch(input.nextName()) {
                    case "body":
                        body = input.nextString();
                        break;
                    case "base64Encoded":
                        base64Encoded = input.nextBoolean();
                        break;
                    default:
                        input.skipValue();
                        break;
                }
            }
            input.endObject();
            return new GetResponseBodyForInterceptionResponse(body, base64Encoded);
        }
    }

    /**
     * Returns content served for the given currently intercepted request.
     */
    @Beta()
    public static Command<org.openqa.selenium.devtools.v146.network.Network.GetResponseBodyForInterceptionResponse> getResponseBodyForInterception(org.openqa.selenium.devtools.v146.network.model.InterceptionId interceptionId) {
        java.util.Objects.requireNonNull(interceptionId, "interceptionId is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("interceptionId", interceptionId);
        return new Command<>("Network.getResponseBodyForInterception", Map.copyOf(params), input -> input.read(org.openqa.selenium.devtools.v146.network.Network.GetResponseBodyForInterceptionResponse.class));
    }

    /**
     * Returns a handle to the stream representing the response body. Note that after this command,
     * the intercepted request can't be continued as is -- you either need to cancel it or to provide
     * the response body. The stream only supports sequential read, IO.read will fail if the position
     * is specified.
     */
    @Beta()
    public static Command<org.openqa.selenium.devtools.v146.io.model.StreamHandle> takeResponseBodyForInterceptionAsStream(org.openqa.selenium.devtools.v146.network.model.InterceptionId interceptionId) {
        java.util.Objects.requireNonNull(interceptionId, "interceptionId is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("interceptionId", interceptionId);
        return new Command<>("Network.takeResponseBodyForInterceptionAsStream", Map.copyOf(params), ConverterFunctions.map("stream", org.openqa.selenium.devtools.v146.io.model.StreamHandle.class));
    }

    /**
     * This method sends a new XMLHttpRequest which is identical to the original one. The following
     * parameters should be identical: method, url, async, request body, extra headers, withCredentials
     * attribute, user, password.
     */
    @Beta()
    public static Command<Void> replayXHR(org.openqa.selenium.devtools.v146.network.model.RequestId requestId) {
        java.util.Objects.requireNonNull(requestId, "requestId is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("requestId", requestId);
        return new Command<>("Network.replayXHR", Map.copyOf(params));
    }

    /**
     * Searches for given string in response content.
     */
    @Beta()
    public static Command<java.util.List<org.openqa.selenium.devtools.v146.debugger.model.SearchMatch>> searchInResponseBody(org.openqa.selenium.devtools.v146.network.model.RequestId requestId, java.lang.String query, java.util.Optional<java.lang.Boolean> caseSensitive, java.util.Optional<java.lang.Boolean> isRegex) {
        java.util.Objects.requireNonNull(requestId, "requestId is required");
        java.util.Objects.requireNonNull(query, "query is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("requestId", requestId);
        params.put("query", query);
        caseSensitive.ifPresent(p -> params.put("caseSensitive", p));
        isRegex.ifPresent(p -> params.put("isRegex", p));
        return new Command<>("Network.searchInResponseBody", Map.copyOf(params), ConverterFunctions.map("result", input -> input.readArray(org.openqa.selenium.devtools.v146.debugger.model.SearchMatch.class)));
    }

    /**
     * Blocks URLs from loading.
     */
    @Beta()
    public static Command<Void> setBlockedURLs(java.util.Optional<java.util.List<org.openqa.selenium.devtools.v146.network.model.BlockPattern>> urlPatterns, java.util.Optional<java.util.List<java.lang.String>> urls) {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        urlPatterns.ifPresent(p -> params.put("urlPatterns", p));
        urls.ifPresent(p -> params.put("urls", p));
        return new Command<>("Network.setBlockedURLs", Map.copyOf(params));
    }

    /**
     * Toggles ignoring of service worker for each request.
     */
    public static Command<Void> setBypassServiceWorker(java.lang.Boolean bypass) {
        java.util.Objects.requireNonNull(bypass, "bypass is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("bypass", bypass);
        return new Command<>("Network.setBypassServiceWorker", Map.copyOf(params));
    }

    /**
     * Toggles ignoring cache for each request. If `true`, cache will not be used.
     */
    public static Command<Void> setCacheDisabled(java.lang.Boolean cacheDisabled) {
        java.util.Objects.requireNonNull(cacheDisabled, "cacheDisabled is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("cacheDisabled", cacheDisabled);
        return new Command<>("Network.setCacheDisabled", Map.copyOf(params));
    }

    /**
     * Sets a cookie with the given cookie data; may overwrite equivalent cookies if they exist.
     */
    public static Command<java.lang.Boolean> setCookie(java.lang.String name, java.lang.String value, java.util.Optional<java.lang.String> url, java.util.Optional<java.lang.String> domain, java.util.Optional<java.lang.String> path, java.util.Optional<java.lang.Boolean> secure, java.util.Optional<java.lang.Boolean> httpOnly, java.util.Optional<org.openqa.selenium.devtools.v146.network.model.CookieSameSite> sameSite, java.util.Optional<org.openqa.selenium.devtools.v146.network.model.TimeSinceEpoch> expires, java.util.Optional<org.openqa.selenium.devtools.v146.network.model.CookiePriority> priority, java.util.Optional<org.openqa.selenium.devtools.v146.network.model.CookieSourceScheme> sourceScheme, java.util.Optional<java.lang.Integer> sourcePort, java.util.Optional<org.openqa.selenium.devtools.v146.network.model.CookiePartitionKey> partitionKey) {
        java.util.Objects.requireNonNull(name, "name is required");
        java.util.Objects.requireNonNull(value, "value is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("name", name);
        params.put("value", value);
        url.ifPresent(p -> params.put("url", p));
        domain.ifPresent(p -> params.put("domain", p));
        path.ifPresent(p -> params.put("path", p));
        secure.ifPresent(p -> params.put("secure", p));
        httpOnly.ifPresent(p -> params.put("httpOnly", p));
        sameSite.ifPresent(p -> params.put("sameSite", p));
        expires.ifPresent(p -> params.put("expires", p));
        priority.ifPresent(p -> params.put("priority", p));
        sourceScheme.ifPresent(p -> params.put("sourceScheme", p));
        sourcePort.ifPresent(p -> params.put("sourcePort", p));
        partitionKey.ifPresent(p -> params.put("partitionKey", p));
        return new Command<>("Network.setCookie", Map.copyOf(params), ConverterFunctions.map("success", java.lang.Boolean.class));
    }

    /**
     * Sets given cookies.
     */
    public static Command<Void> setCookies(java.util.List<org.openqa.selenium.devtools.v146.network.model.CookieParam> cookies) {
        java.util.Objects.requireNonNull(cookies, "cookies is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("cookies", cookies);
        return new Command<>("Network.setCookies", Map.copyOf(params));
    }

    /**
     * Specifies whether to always send extra HTTP headers with the requests from this page.
     */
    public static Command<Void> setExtraHTTPHeaders(org.openqa.selenium.devtools.v146.network.model.Headers headers) {
        java.util.Objects.requireNonNull(headers, "headers is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("headers", headers);
        return new Command<>("Network.setExtraHTTPHeaders", Map.copyOf(params));
    }

    /**
     * Specifies whether to attach a page script stack id in requests
     */
    @Beta()
    public static Command<Void> setAttachDebugStack(java.lang.Boolean enabled) {
        java.util.Objects.requireNonNull(enabled, "enabled is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("enabled", enabled);
        return new Command<>("Network.setAttachDebugStack", Map.copyOf(params));
    }

    /**
     * Sets the requests to intercept that match the provided patterns and optionally resource types.
     * Deprecated, please use Fetch.enable instead.
     */
    @Beta()
    @Deprecated()
    public static Command<Void> setRequestInterception(java.util.List<org.openqa.selenium.devtools.v146.network.model.RequestPattern> patterns) {
        java.util.Objects.requireNonNull(patterns, "patterns is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("patterns", patterns);
        return new Command<>("Network.setRequestInterception", Map.copyOf(params));
    }

    /**
     * Allows overriding user agent with the given string.
     */
    public static Command<Void> setUserAgentOverride(java.lang.String userAgent, java.util.Optional<java.lang.String> acceptLanguage, java.util.Optional<java.lang.String> platform, java.util.Optional<org.openqa.selenium.devtools.v146.emulation.model.UserAgentMetadata> userAgentMetadata) {
        java.util.Objects.requireNonNull(userAgent, "userAgent is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("userAgent", userAgent);
        acceptLanguage.ifPresent(p -> params.put("acceptLanguage", p));
        platform.ifPresent(p -> params.put("platform", p));
        userAgentMetadata.ifPresent(p -> params.put("userAgentMetadata", p));
        return new Command<>("Network.setUserAgentOverride", Map.copyOf(params));
    }

    /**
     * Enables streaming of the response for the given requestId.
     * If enabled, the dataReceived event contains the data that was received during streaming.
     */
    @Beta()
    public static Command<java.lang.String> streamResourceContent(org.openqa.selenium.devtools.v146.network.model.RequestId requestId) {
        java.util.Objects.requireNonNull(requestId, "requestId is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("requestId", requestId);
        return new Command<>("Network.streamResourceContent", Map.copyOf(params), ConverterFunctions.map("bufferedData", java.lang.String.class));
    }

    /**
     * Returns information about the COEP/COOP isolation status.
     */
    @Beta()
    public static Command<org.openqa.selenium.devtools.v146.network.model.SecurityIsolationStatus> getSecurityIsolationStatus(java.util.Optional<org.openqa.selenium.devtools.v146.page.model.FrameId> frameId) {
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        frameId.ifPresent(p -> params.put("frameId", p));
        return new Command<>("Network.getSecurityIsolationStatus", Map.copyOf(params), ConverterFunctions.map("status", org.openqa.selenium.devtools.v146.network.model.SecurityIsolationStatus.class));
    }

    /**
     * Enables tracking for the Reporting API, events generated by the Reporting API will now be delivered to the client.
     * Enabling triggers 'reportingApiReportAdded' for all existing reports.
     */
    @Beta()
    public static Command<Void> enableReportingApi(java.lang.Boolean enable) {
        java.util.Objects.requireNonNull(enable, "enable is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("enable", enable);
        return new Command<>("Network.enableReportingApi", Map.copyOf(params));
    }

    /**
     * Sets up tracking device bound sessions and fetching of initial set of sessions.
     */
    @Beta()
    public static Command<Void> enableDeviceBoundSessions(java.lang.Boolean enable) {
        java.util.Objects.requireNonNull(enable, "enable is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("enable", enable);
        return new Command<>("Network.enableDeviceBoundSessions", Map.copyOf(params));
    }

    /**
     * Fetches the schemeful site for a specific origin.
     */
    @Beta()
    public static Command<java.lang.String> fetchSchemefulSite(java.lang.String origin) {
        java.util.Objects.requireNonNull(origin, "origin is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("origin", origin);
        return new Command<>("Network.fetchSchemefulSite", Map.copyOf(params), ConverterFunctions.map("schemefulSite", java.lang.String.class));
    }

    /**
     * Fetches the resource and returns the content.
     */
    @Beta()
    public static Command<org.openqa.selenium.devtools.v146.network.model.LoadNetworkResourcePageResult> loadNetworkResource(java.util.Optional<org.openqa.selenium.devtools.v146.page.model.FrameId> frameId, java.lang.String url, org.openqa.selenium.devtools.v146.network.model.LoadNetworkResourceOptions options) {
        java.util.Objects.requireNonNull(url, "url is required");
        java.util.Objects.requireNonNull(options, "options is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        frameId.ifPresent(p -> params.put("frameId", p));
        params.put("url", url);
        params.put("options", options);
        return new Command<>("Network.loadNetworkResource", Map.copyOf(params), ConverterFunctions.map("resource", org.openqa.selenium.devtools.v146.network.model.LoadNetworkResourcePageResult.class));
    }

    /**
     * Sets Controls for third-party cookie access
     * Page reload is required before the new cookie behavior will be observed
     */
    @Beta()
    public static Command<Void> setCookieControls(java.lang.Boolean enableThirdPartyCookieRestriction, java.lang.Boolean disableThirdPartyCookieMetadata, java.lang.Boolean disableThirdPartyCookieHeuristics) {
        java.util.Objects.requireNonNull(enableThirdPartyCookieRestriction, "enableThirdPartyCookieRestriction is required");
        java.util.Objects.requireNonNull(disableThirdPartyCookieMetadata, "disableThirdPartyCookieMetadata is required");
        java.util.Objects.requireNonNull(disableThirdPartyCookieHeuristics, "disableThirdPartyCookieHeuristics is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("enableThirdPartyCookieRestriction", enableThirdPartyCookieRestriction);
        params.put("disableThirdPartyCookieMetadata", disableThirdPartyCookieMetadata);
        params.put("disableThirdPartyCookieHeuristics", disableThirdPartyCookieHeuristics);
        return new Command<>("Network.setCookieControls", Map.copyOf(params));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.DataReceived> dataReceived() {
        return new Event<>("Network.dataReceived", input -> input.read(org.openqa.selenium.devtools.v146.network.model.DataReceived.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.EventSourceMessageReceived> eventSourceMessageReceived() {
        return new Event<>("Network.eventSourceMessageReceived", input -> input.read(org.openqa.selenium.devtools.v146.network.model.EventSourceMessageReceived.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.LoadingFailed> loadingFailed() {
        return new Event<>("Network.loadingFailed", input -> input.read(org.openqa.selenium.devtools.v146.network.model.LoadingFailed.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.LoadingFinished> loadingFinished() {
        return new Event<>("Network.loadingFinished", input -> input.read(org.openqa.selenium.devtools.v146.network.model.LoadingFinished.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.RequestIntercepted> requestIntercepted() {
        return new Event<>("Network.requestIntercepted", input -> input.read(org.openqa.selenium.devtools.v146.network.model.RequestIntercepted.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.RequestId> requestServedFromCache() {
        return new Event<>("Network.requestServedFromCache", ConverterFunctions.map("requestId", org.openqa.selenium.devtools.v146.network.model.RequestId.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.RequestWillBeSent> requestWillBeSent() {
        return new Event<>("Network.requestWillBeSent", input -> input.read(org.openqa.selenium.devtools.v146.network.model.RequestWillBeSent.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.ResourceChangedPriority> resourceChangedPriority() {
        return new Event<>("Network.resourceChangedPriority", input -> input.read(org.openqa.selenium.devtools.v146.network.model.ResourceChangedPriority.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.SignedExchangeReceived> signedExchangeReceived() {
        return new Event<>("Network.signedExchangeReceived", input -> input.read(org.openqa.selenium.devtools.v146.network.model.SignedExchangeReceived.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.ResponseReceived> responseReceived() {
        return new Event<>("Network.responseReceived", input -> input.read(org.openqa.selenium.devtools.v146.network.model.ResponseReceived.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.WebSocketClosed> webSocketClosed() {
        return new Event<>("Network.webSocketClosed", input -> input.read(org.openqa.selenium.devtools.v146.network.model.WebSocketClosed.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.WebSocketCreated> webSocketCreated() {
        return new Event<>("Network.webSocketCreated", input -> input.read(org.openqa.selenium.devtools.v146.network.model.WebSocketCreated.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.WebSocketFrameError> webSocketFrameError() {
        return new Event<>("Network.webSocketFrameError", input -> input.read(org.openqa.selenium.devtools.v146.network.model.WebSocketFrameError.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.WebSocketFrameReceived> webSocketFrameReceived() {
        return new Event<>("Network.webSocketFrameReceived", input -> input.read(org.openqa.selenium.devtools.v146.network.model.WebSocketFrameReceived.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.WebSocketFrameSent> webSocketFrameSent() {
        return new Event<>("Network.webSocketFrameSent", input -> input.read(org.openqa.selenium.devtools.v146.network.model.WebSocketFrameSent.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.WebSocketHandshakeResponseReceived> webSocketHandshakeResponseReceived() {
        return new Event<>("Network.webSocketHandshakeResponseReceived", input -> input.read(org.openqa.selenium.devtools.v146.network.model.WebSocketHandshakeResponseReceived.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.WebSocketWillSendHandshakeRequest> webSocketWillSendHandshakeRequest() {
        return new Event<>("Network.webSocketWillSendHandshakeRequest", input -> input.read(org.openqa.selenium.devtools.v146.network.model.WebSocketWillSendHandshakeRequest.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.WebTransportCreated> webTransportCreated() {
        return new Event<>("Network.webTransportCreated", input -> input.read(org.openqa.selenium.devtools.v146.network.model.WebTransportCreated.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.WebTransportConnectionEstablished> webTransportConnectionEstablished() {
        return new Event<>("Network.webTransportConnectionEstablished", input -> input.read(org.openqa.selenium.devtools.v146.network.model.WebTransportConnectionEstablished.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.WebTransportClosed> webTransportClosed() {
        return new Event<>("Network.webTransportClosed", input -> input.read(org.openqa.selenium.devtools.v146.network.model.WebTransportClosed.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.DirectTCPSocketCreated> directTCPSocketCreated() {
        return new Event<>("Network.directTCPSocketCreated", input -> input.read(org.openqa.selenium.devtools.v146.network.model.DirectTCPSocketCreated.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.DirectTCPSocketOpened> directTCPSocketOpened() {
        return new Event<>("Network.directTCPSocketOpened", input -> input.read(org.openqa.selenium.devtools.v146.network.model.DirectTCPSocketOpened.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.DirectTCPSocketAborted> directTCPSocketAborted() {
        return new Event<>("Network.directTCPSocketAborted", input -> input.read(org.openqa.selenium.devtools.v146.network.model.DirectTCPSocketAborted.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.DirectTCPSocketClosed> directTCPSocketClosed() {
        return new Event<>("Network.directTCPSocketClosed", input -> input.read(org.openqa.selenium.devtools.v146.network.model.DirectTCPSocketClosed.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.DirectTCPSocketChunkSent> directTCPSocketChunkSent() {
        return new Event<>("Network.directTCPSocketChunkSent", input -> input.read(org.openqa.selenium.devtools.v146.network.model.DirectTCPSocketChunkSent.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.DirectTCPSocketChunkReceived> directTCPSocketChunkReceived() {
        return new Event<>("Network.directTCPSocketChunkReceived", input -> input.read(org.openqa.selenium.devtools.v146.network.model.DirectTCPSocketChunkReceived.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.DirectUDPSocketJoinedMulticastGroup> directUDPSocketJoinedMulticastGroup() {
        return new Event<>("Network.directUDPSocketJoinedMulticastGroup", input -> input.read(org.openqa.selenium.devtools.v146.network.model.DirectUDPSocketJoinedMulticastGroup.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.DirectUDPSocketLeftMulticastGroup> directUDPSocketLeftMulticastGroup() {
        return new Event<>("Network.directUDPSocketLeftMulticastGroup", input -> input.read(org.openqa.selenium.devtools.v146.network.model.DirectUDPSocketLeftMulticastGroup.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.DirectUDPSocketCreated> directUDPSocketCreated() {
        return new Event<>("Network.directUDPSocketCreated", input -> input.read(org.openqa.selenium.devtools.v146.network.model.DirectUDPSocketCreated.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.DirectUDPSocketOpened> directUDPSocketOpened() {
        return new Event<>("Network.directUDPSocketOpened", input -> input.read(org.openqa.selenium.devtools.v146.network.model.DirectUDPSocketOpened.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.DirectUDPSocketAborted> directUDPSocketAborted() {
        return new Event<>("Network.directUDPSocketAborted", input -> input.read(org.openqa.selenium.devtools.v146.network.model.DirectUDPSocketAborted.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.DirectUDPSocketClosed> directUDPSocketClosed() {
        return new Event<>("Network.directUDPSocketClosed", input -> input.read(org.openqa.selenium.devtools.v146.network.model.DirectUDPSocketClosed.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.DirectUDPSocketChunkSent> directUDPSocketChunkSent() {
        return new Event<>("Network.directUDPSocketChunkSent", input -> input.read(org.openqa.selenium.devtools.v146.network.model.DirectUDPSocketChunkSent.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.DirectUDPSocketChunkReceived> directUDPSocketChunkReceived() {
        return new Event<>("Network.directUDPSocketChunkReceived", input -> input.read(org.openqa.selenium.devtools.v146.network.model.DirectUDPSocketChunkReceived.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.RequestWillBeSentExtraInfo> requestWillBeSentExtraInfo() {
        return new Event<>("Network.requestWillBeSentExtraInfo", input -> input.read(org.openqa.selenium.devtools.v146.network.model.RequestWillBeSentExtraInfo.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.ResponseReceivedExtraInfo> responseReceivedExtraInfo() {
        return new Event<>("Network.responseReceivedExtraInfo", input -> input.read(org.openqa.selenium.devtools.v146.network.model.ResponseReceivedExtraInfo.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.ResponseReceivedEarlyHints> responseReceivedEarlyHints() {
        return new Event<>("Network.responseReceivedEarlyHints", input -> input.read(org.openqa.selenium.devtools.v146.network.model.ResponseReceivedEarlyHints.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.TrustTokenOperationDone> trustTokenOperationDone() {
        return new Event<>("Network.trustTokenOperationDone", input -> input.read(org.openqa.selenium.devtools.v146.network.model.TrustTokenOperationDone.class));
    }

    public static Event<Void> policyUpdated() {
        return new Event<>("Network.policyUpdated", ConverterFunctions.empty());
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.ReportingApiReport> reportingApiReportAdded() {
        return new Event<>("Network.reportingApiReportAdded", ConverterFunctions.map("report", org.openqa.selenium.devtools.v146.network.model.ReportingApiReport.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.ReportingApiReport> reportingApiReportUpdated() {
        return new Event<>("Network.reportingApiReportUpdated", ConverterFunctions.map("report", org.openqa.selenium.devtools.v146.network.model.ReportingApiReport.class));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.ReportingApiEndpointsChangedForOrigin> reportingApiEndpointsChangedForOrigin() {
        return new Event<>("Network.reportingApiEndpointsChangedForOrigin", input -> input.read(org.openqa.selenium.devtools.v146.network.model.ReportingApiEndpointsChangedForOrigin.class));
    }

    public static Event<java.util.List<org.openqa.selenium.devtools.v146.network.model.DeviceBoundSession>> deviceBoundSessionsAdded() {
        return new Event<>("Network.deviceBoundSessionsAdded", ConverterFunctions.map("sessions", input -> input.readArray(org.openqa.selenium.devtools.v146.network.model.DeviceBoundSession.class)));
    }

    public static Event<org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionEventOccurred> deviceBoundSessionEventOccurred() {
        return new Event<>("Network.deviceBoundSessionEventOccurred", input -> input.read(org.openqa.selenium.devtools.v146.network.model.DeviceBoundSessionEventOccurred.class));
    }
}
