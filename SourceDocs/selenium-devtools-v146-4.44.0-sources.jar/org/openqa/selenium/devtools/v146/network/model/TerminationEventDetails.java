package org.openqa.selenium.devtools.v146.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Session event details specific to termination.
 */
@org.openqa.selenium.Beta()
public class TerminationEventDetails {

    public enum DeletionReason {

        EXPIRED("Expired"),
        FAILEDTORESTOREKEY("FailedToRestoreKey"),
        FAILEDTOUNWRAPKEY("FailedToUnwrapKey"),
        STORAGEPARTITIONCLEARED("StoragePartitionCleared"),
        CLEARBROWSINGDATA("ClearBrowsingData"),
        SERVERREQUESTED("ServerRequested"),
        INVALIDSESSIONPARAMS("InvalidSessionParams"),
        REFRESHFATALERROR("RefreshFatalError");

        private String value;

        DeletionReason(String value) {
            this.value = value;
        }

        public static DeletionReason fromString(String s) {
            return java.util.Arrays.stream(DeletionReason.values()).filter(rs -> rs.value.equalsIgnoreCase(s)).findFirst().orElseThrow(() -> new org.openqa.selenium.devtools.DevToolsException("Given value " + s + " is not found within DeletionReason "));
        }

        public String toString() {
            return value;
        }

        public String toJson() {
            return value;
        }

        private static DeletionReason fromJson(JsonInput input) {
            return fromString(input.nextString());
        }
    }

    private final DeletionReason deletionReason;

    public TerminationEventDetails(DeletionReason deletionReason) {
        this.deletionReason = java.util.Objects.requireNonNull(deletionReason, "deletionReason is required");
    }

    /**
     * The reason for a session being deleted.
     */
    public DeletionReason getDeletionReason() {
        return deletionReason;
    }

    private static TerminationEventDetails fromJson(JsonInput input) {
        DeletionReason deletionReason = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "deletionReason":
                    deletionReason = DeletionReason.fromString(input.nextString());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new TerminationEventDetails(deletionReason);
    }
}
