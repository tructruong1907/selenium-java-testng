package org.openqa.selenium.devtools.v148.filesystem;

import org.openqa.selenium.Beta;
import org.openqa.selenium.devtools.Command;
import org.openqa.selenium.devtools.Event;
import org.openqa.selenium.devtools.ConverterFunctions;
import java.util.Map;
import java.util.LinkedHashMap;
import org.openqa.selenium.json.JsonInput;

@Beta()
public class FileSystem {

    public static Command<org.openqa.selenium.devtools.v148.filesystem.model.Directory> getDirectory(org.openqa.selenium.devtools.v148.filesystem.model.BucketFileSystemLocator bucketFileSystemLocator) {
        java.util.Objects.requireNonNull(bucketFileSystemLocator, "bucketFileSystemLocator is required");
        LinkedHashMap<String, Object> params = new LinkedHashMap<>();
        params.put("bucketFileSystemLocator", bucketFileSystemLocator);
        return new Command<>("FileSystem.getDirectory", Map.copyOf(params), ConverterFunctions.map("directory", org.openqa.selenium.devtools.v148.filesystem.model.Directory.class));
    }
}
