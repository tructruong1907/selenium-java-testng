package org.openqa.selenium.devtools.v148.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Identifies the script on the stack that caused a resource or element to be
 * labeled as an ad. For resources, this indicates the context that triggered
 * the fetch. For elements, this indicates the context that caused the element
 * to be appended to the DOM.
 */
@org.openqa.selenium.Beta()
public class AdScriptIdentifier {

    private final org.openqa.selenium.devtools.v148.runtime.model.ScriptId scriptId;

    private final org.openqa.selenium.devtools.v148.runtime.model.UniqueDebuggerId debuggerId;

    private final java.lang.String name;

    public AdScriptIdentifier(org.openqa.selenium.devtools.v148.runtime.model.ScriptId scriptId, org.openqa.selenium.devtools.v148.runtime.model.UniqueDebuggerId debuggerId, java.lang.String name) {
        this.scriptId = java.util.Objects.requireNonNull(scriptId, "scriptId is required");
        this.debuggerId = java.util.Objects.requireNonNull(debuggerId, "debuggerId is required");
        this.name = java.util.Objects.requireNonNull(name, "name is required");
    }

    /**
     * The script's V8 identifier.
     */
    public org.openqa.selenium.devtools.v148.runtime.model.ScriptId getScriptId() {
        return scriptId;
    }

    /**
     * V8's debugging ID for the v8::Context.
     */
    public org.openqa.selenium.devtools.v148.runtime.model.UniqueDebuggerId getDebuggerId() {
        return debuggerId;
    }

    /**
     * The script's url (or generated name based on id if inline script).
     */
    public java.lang.String getName() {
        return name;
    }

    private static AdScriptIdentifier fromJson(JsonInput input) {
        org.openqa.selenium.devtools.v148.runtime.model.ScriptId scriptId = null;
        org.openqa.selenium.devtools.v148.runtime.model.UniqueDebuggerId debuggerId = null;
        java.lang.String name = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "scriptId":
                    scriptId = input.read(org.openqa.selenium.devtools.v148.runtime.model.ScriptId.class);
                    break;
                case "debuggerId":
                    debuggerId = input.read(org.openqa.selenium.devtools.v148.runtime.model.UniqueDebuggerId.class);
                    break;
                case "name":
                    name = input.nextString();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AdScriptIdentifier(scriptId, debuggerId, name);
    }
}
