package org.openqa.selenium.devtools.v148.page.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class LaunchHandler {

    private final java.lang.String clientMode;

    public LaunchHandler(java.lang.String clientMode) {
        this.clientMode = java.util.Objects.requireNonNull(clientMode, "clientMode is required");
    }

    public java.lang.String getClientMode() {
        return clientMode;
    }

    private static LaunchHandler fromJson(JsonInput input) {
        java.lang.String clientMode = null;
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "clientMode":
                    clientMode = input.nextString();
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new LaunchHandler(clientMode);
    }
}
