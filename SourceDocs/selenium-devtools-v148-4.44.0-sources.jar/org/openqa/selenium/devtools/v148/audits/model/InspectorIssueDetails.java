package org.openqa.selenium.devtools.v148.audits.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * This struct holds a list of optional fields with additional information
 * specific to the kind of issue. When adding a new issue code, please also
 * add a new optional field to this type.
 */
public class InspectorIssueDetails {

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.CookieIssueDetails> cookieIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.MixedContentIssueDetails> mixedContentIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.BlockedByResponseIssueDetails> blockedByResponseIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.HeavyAdIssueDetails> heavyAdIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.ContentSecurityPolicyIssueDetails> contentSecurityPolicyIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SharedArrayBufferIssueDetails> sharedArrayBufferIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.CorsIssueDetails> corsIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.AttributionReportingIssueDetails> attributionReportingIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.QuirksModeIssueDetails> quirksModeIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.PartitioningBlobURLIssueDetails> partitioningBlobURLIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.NavigatorUserAgentIssueDetails> navigatorUserAgentIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.GenericIssueDetails> genericIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.DeprecationIssueDetails> deprecationIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.ClientHintIssueDetails> clientHintIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.FederatedAuthRequestIssueDetails> federatedAuthRequestIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.BounceTrackingIssueDetails> bounceTrackingIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.CookieDeprecationMetadataIssueDetails> cookieDeprecationMetadataIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.StylesheetLoadingIssueDetails> stylesheetLoadingIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.PropertyRuleIssueDetails> propertyRuleIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.FederatedAuthUserInfoRequestIssueDetails> federatedAuthUserInfoRequestIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SharedDictionaryIssueDetails> sharedDictionaryIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.ElementAccessibilityIssueDetails> elementAccessibilityIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SRIMessageSignatureIssueDetails> sriMessageSignatureIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.UnencodedDigestIssueDetails> unencodedDigestIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.ConnectionAllowlistIssueDetails> connectionAllowlistIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.UserReidentificationIssueDetails> userReidentificationIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.PermissionElementIssueDetails> permissionElementIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.PerformanceIssueDetails> performanceIssueDetails;

    private final java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SelectivePermissionsInterventionIssueDetails> selectivePermissionsInterventionIssueDetails;

    public InspectorIssueDetails(java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.CookieIssueDetails> cookieIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.MixedContentIssueDetails> mixedContentIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.BlockedByResponseIssueDetails> blockedByResponseIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.HeavyAdIssueDetails> heavyAdIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.ContentSecurityPolicyIssueDetails> contentSecurityPolicyIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SharedArrayBufferIssueDetails> sharedArrayBufferIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.CorsIssueDetails> corsIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.AttributionReportingIssueDetails> attributionReportingIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.QuirksModeIssueDetails> quirksModeIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.PartitioningBlobURLIssueDetails> partitioningBlobURLIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.NavigatorUserAgentIssueDetails> navigatorUserAgentIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.GenericIssueDetails> genericIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.DeprecationIssueDetails> deprecationIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.ClientHintIssueDetails> clientHintIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.FederatedAuthRequestIssueDetails> federatedAuthRequestIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.BounceTrackingIssueDetails> bounceTrackingIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.CookieDeprecationMetadataIssueDetails> cookieDeprecationMetadataIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.StylesheetLoadingIssueDetails> stylesheetLoadingIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.PropertyRuleIssueDetails> propertyRuleIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.FederatedAuthUserInfoRequestIssueDetails> federatedAuthUserInfoRequestIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SharedDictionaryIssueDetails> sharedDictionaryIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.ElementAccessibilityIssueDetails> elementAccessibilityIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SRIMessageSignatureIssueDetails> sriMessageSignatureIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.UnencodedDigestIssueDetails> unencodedDigestIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.ConnectionAllowlistIssueDetails> connectionAllowlistIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.UserReidentificationIssueDetails> userReidentificationIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.PermissionElementIssueDetails> permissionElementIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.PerformanceIssueDetails> performanceIssueDetails, java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SelectivePermissionsInterventionIssueDetails> selectivePermissionsInterventionIssueDetails) {
        this.cookieIssueDetails = cookieIssueDetails;
        this.mixedContentIssueDetails = mixedContentIssueDetails;
        this.blockedByResponseIssueDetails = blockedByResponseIssueDetails;
        this.heavyAdIssueDetails = heavyAdIssueDetails;
        this.contentSecurityPolicyIssueDetails = contentSecurityPolicyIssueDetails;
        this.sharedArrayBufferIssueDetails = sharedArrayBufferIssueDetails;
        this.corsIssueDetails = corsIssueDetails;
        this.attributionReportingIssueDetails = attributionReportingIssueDetails;
        this.quirksModeIssueDetails = quirksModeIssueDetails;
        this.partitioningBlobURLIssueDetails = partitioningBlobURLIssueDetails;
        this.navigatorUserAgentIssueDetails = navigatorUserAgentIssueDetails;
        this.genericIssueDetails = genericIssueDetails;
        this.deprecationIssueDetails = deprecationIssueDetails;
        this.clientHintIssueDetails = clientHintIssueDetails;
        this.federatedAuthRequestIssueDetails = federatedAuthRequestIssueDetails;
        this.bounceTrackingIssueDetails = bounceTrackingIssueDetails;
        this.cookieDeprecationMetadataIssueDetails = cookieDeprecationMetadataIssueDetails;
        this.stylesheetLoadingIssueDetails = stylesheetLoadingIssueDetails;
        this.propertyRuleIssueDetails = propertyRuleIssueDetails;
        this.federatedAuthUserInfoRequestIssueDetails = federatedAuthUserInfoRequestIssueDetails;
        this.sharedDictionaryIssueDetails = sharedDictionaryIssueDetails;
        this.elementAccessibilityIssueDetails = elementAccessibilityIssueDetails;
        this.sriMessageSignatureIssueDetails = sriMessageSignatureIssueDetails;
        this.unencodedDigestIssueDetails = unencodedDigestIssueDetails;
        this.connectionAllowlistIssueDetails = connectionAllowlistIssueDetails;
        this.userReidentificationIssueDetails = userReidentificationIssueDetails;
        this.permissionElementIssueDetails = permissionElementIssueDetails;
        this.performanceIssueDetails = performanceIssueDetails;
        this.selectivePermissionsInterventionIssueDetails = selectivePermissionsInterventionIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.CookieIssueDetails> getCookieIssueDetails() {
        return cookieIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.MixedContentIssueDetails> getMixedContentIssueDetails() {
        return mixedContentIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.BlockedByResponseIssueDetails> getBlockedByResponseIssueDetails() {
        return blockedByResponseIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.HeavyAdIssueDetails> getHeavyAdIssueDetails() {
        return heavyAdIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.ContentSecurityPolicyIssueDetails> getContentSecurityPolicyIssueDetails() {
        return contentSecurityPolicyIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SharedArrayBufferIssueDetails> getSharedArrayBufferIssueDetails() {
        return sharedArrayBufferIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.CorsIssueDetails> getCorsIssueDetails() {
        return corsIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.AttributionReportingIssueDetails> getAttributionReportingIssueDetails() {
        return attributionReportingIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.QuirksModeIssueDetails> getQuirksModeIssueDetails() {
        return quirksModeIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.PartitioningBlobURLIssueDetails> getPartitioningBlobURLIssueDetails() {
        return partitioningBlobURLIssueDetails;
    }

    @Deprecated()
    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.NavigatorUserAgentIssueDetails> getNavigatorUserAgentIssueDetails() {
        return navigatorUserAgentIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.GenericIssueDetails> getGenericIssueDetails() {
        return genericIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.DeprecationIssueDetails> getDeprecationIssueDetails() {
        return deprecationIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.ClientHintIssueDetails> getClientHintIssueDetails() {
        return clientHintIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.FederatedAuthRequestIssueDetails> getFederatedAuthRequestIssueDetails() {
        return federatedAuthRequestIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.BounceTrackingIssueDetails> getBounceTrackingIssueDetails() {
        return bounceTrackingIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.CookieDeprecationMetadataIssueDetails> getCookieDeprecationMetadataIssueDetails() {
        return cookieDeprecationMetadataIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.StylesheetLoadingIssueDetails> getStylesheetLoadingIssueDetails() {
        return stylesheetLoadingIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.PropertyRuleIssueDetails> getPropertyRuleIssueDetails() {
        return propertyRuleIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.FederatedAuthUserInfoRequestIssueDetails> getFederatedAuthUserInfoRequestIssueDetails() {
        return federatedAuthUserInfoRequestIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SharedDictionaryIssueDetails> getSharedDictionaryIssueDetails() {
        return sharedDictionaryIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.ElementAccessibilityIssueDetails> getElementAccessibilityIssueDetails() {
        return elementAccessibilityIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SRIMessageSignatureIssueDetails> getSriMessageSignatureIssueDetails() {
        return sriMessageSignatureIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.UnencodedDigestIssueDetails> getUnencodedDigestIssueDetails() {
        return unencodedDigestIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.ConnectionAllowlistIssueDetails> getConnectionAllowlistIssueDetails() {
        return connectionAllowlistIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.UserReidentificationIssueDetails> getUserReidentificationIssueDetails() {
        return userReidentificationIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.PermissionElementIssueDetails> getPermissionElementIssueDetails() {
        return permissionElementIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.PerformanceIssueDetails> getPerformanceIssueDetails() {
        return performanceIssueDetails;
    }

    public java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SelectivePermissionsInterventionIssueDetails> getSelectivePermissionsInterventionIssueDetails() {
        return selectivePermissionsInterventionIssueDetails;
    }

    private static InspectorIssueDetails fromJson(JsonInput input) {
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.CookieIssueDetails> cookieIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.MixedContentIssueDetails> mixedContentIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.BlockedByResponseIssueDetails> blockedByResponseIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.HeavyAdIssueDetails> heavyAdIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.ContentSecurityPolicyIssueDetails> contentSecurityPolicyIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SharedArrayBufferIssueDetails> sharedArrayBufferIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.CorsIssueDetails> corsIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.AttributionReportingIssueDetails> attributionReportingIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.QuirksModeIssueDetails> quirksModeIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.PartitioningBlobURLIssueDetails> partitioningBlobURLIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.NavigatorUserAgentIssueDetails> navigatorUserAgentIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.GenericIssueDetails> genericIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.DeprecationIssueDetails> deprecationIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.ClientHintIssueDetails> clientHintIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.FederatedAuthRequestIssueDetails> federatedAuthRequestIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.BounceTrackingIssueDetails> bounceTrackingIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.CookieDeprecationMetadataIssueDetails> cookieDeprecationMetadataIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.StylesheetLoadingIssueDetails> stylesheetLoadingIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.PropertyRuleIssueDetails> propertyRuleIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.FederatedAuthUserInfoRequestIssueDetails> federatedAuthUserInfoRequestIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SharedDictionaryIssueDetails> sharedDictionaryIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.ElementAccessibilityIssueDetails> elementAccessibilityIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SRIMessageSignatureIssueDetails> sriMessageSignatureIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.UnencodedDigestIssueDetails> unencodedDigestIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.ConnectionAllowlistIssueDetails> connectionAllowlistIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.UserReidentificationIssueDetails> userReidentificationIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.PermissionElementIssueDetails> permissionElementIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.PerformanceIssueDetails> performanceIssueDetails = java.util.Optional.empty();
        java.util.Optional<org.openqa.selenium.devtools.v148.audits.model.SelectivePermissionsInterventionIssueDetails> selectivePermissionsInterventionIssueDetails = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "cookieIssueDetails":
                    cookieIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.CookieIssueDetails.class));
                    break;
                case "mixedContentIssueDetails":
                    mixedContentIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.MixedContentIssueDetails.class));
                    break;
                case "blockedByResponseIssueDetails":
                    blockedByResponseIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.BlockedByResponseIssueDetails.class));
                    break;
                case "heavyAdIssueDetails":
                    heavyAdIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.HeavyAdIssueDetails.class));
                    break;
                case "contentSecurityPolicyIssueDetails":
                    contentSecurityPolicyIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.ContentSecurityPolicyIssueDetails.class));
                    break;
                case "sharedArrayBufferIssueDetails":
                    sharedArrayBufferIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.SharedArrayBufferIssueDetails.class));
                    break;
                case "corsIssueDetails":
                    corsIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.CorsIssueDetails.class));
                    break;
                case "attributionReportingIssueDetails":
                    attributionReportingIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.AttributionReportingIssueDetails.class));
                    break;
                case "quirksModeIssueDetails":
                    quirksModeIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.QuirksModeIssueDetails.class));
                    break;
                case "partitioningBlobURLIssueDetails":
                    partitioningBlobURLIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.PartitioningBlobURLIssueDetails.class));
                    break;
                case "navigatorUserAgentIssueDetails":
                    navigatorUserAgentIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.NavigatorUserAgentIssueDetails.class));
                    break;
                case "genericIssueDetails":
                    genericIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.GenericIssueDetails.class));
                    break;
                case "deprecationIssueDetails":
                    deprecationIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.DeprecationIssueDetails.class));
                    break;
                case "clientHintIssueDetails":
                    clientHintIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.ClientHintIssueDetails.class));
                    break;
                case "federatedAuthRequestIssueDetails":
                    federatedAuthRequestIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.FederatedAuthRequestIssueDetails.class));
                    break;
                case "bounceTrackingIssueDetails":
                    bounceTrackingIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.BounceTrackingIssueDetails.class));
                    break;
                case "cookieDeprecationMetadataIssueDetails":
                    cookieDeprecationMetadataIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.CookieDeprecationMetadataIssueDetails.class));
                    break;
                case "stylesheetLoadingIssueDetails":
                    stylesheetLoadingIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.StylesheetLoadingIssueDetails.class));
                    break;
                case "propertyRuleIssueDetails":
                    propertyRuleIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.PropertyRuleIssueDetails.class));
                    break;
                case "federatedAuthUserInfoRequestIssueDetails":
                    federatedAuthUserInfoRequestIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.FederatedAuthUserInfoRequestIssueDetails.class));
                    break;
                case "sharedDictionaryIssueDetails":
                    sharedDictionaryIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.SharedDictionaryIssueDetails.class));
                    break;
                case "elementAccessibilityIssueDetails":
                    elementAccessibilityIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.ElementAccessibilityIssueDetails.class));
                    break;
                case "sriMessageSignatureIssueDetails":
                    sriMessageSignatureIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.SRIMessageSignatureIssueDetails.class));
                    break;
                case "unencodedDigestIssueDetails":
                    unencodedDigestIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.UnencodedDigestIssueDetails.class));
                    break;
                case "connectionAllowlistIssueDetails":
                    connectionAllowlistIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.ConnectionAllowlistIssueDetails.class));
                    break;
                case "userReidentificationIssueDetails":
                    userReidentificationIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.UserReidentificationIssueDetails.class));
                    break;
                case "permissionElementIssueDetails":
                    permissionElementIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.PermissionElementIssueDetails.class));
                    break;
                case "performanceIssueDetails":
                    performanceIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.PerformanceIssueDetails.class));
                    break;
                case "selectivePermissionsInterventionIssueDetails":
                    selectivePermissionsInterventionIssueDetails = java.util.Optional.ofNullable(input.read(org.openqa.selenium.devtools.v148.audits.model.SelectivePermissionsInterventionIssueDetails.class));
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new InspectorIssueDetails(cookieIssueDetails, mixedContentIssueDetails, blockedByResponseIssueDetails, heavyAdIssueDetails, contentSecurityPolicyIssueDetails, sharedArrayBufferIssueDetails, corsIssueDetails, attributionReportingIssueDetails, quirksModeIssueDetails, partitioningBlobURLIssueDetails, navigatorUserAgentIssueDetails, genericIssueDetails, deprecationIssueDetails, clientHintIssueDetails, federatedAuthRequestIssueDetails, bounceTrackingIssueDetails, cookieDeprecationMetadataIssueDetails, stylesheetLoadingIssueDetails, propertyRuleIssueDetails, federatedAuthUserInfoRequestIssueDetails, sharedDictionaryIssueDetails, elementAccessibilityIssueDetails, sriMessageSignatureIssueDetails, unencodedDigestIssueDetails, connectionAllowlistIssueDetails, userReidentificationIssueDetails, permissionElementIssueDetails, performanceIssueDetails, selectivePermissionsInterventionIssueDetails);
    }
}
