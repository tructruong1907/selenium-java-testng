package org.openqa.selenium.devtools.v147.audits.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Providence about how an ad script was determined to be such. It is an ad
 * because its url matched a filterlist rule, or because some other ad script
 * was on the stack when this script was loaded.
 */
public class AdAncestry {

    private final java.util.List<org.openqa.selenium.devtools.v147.audits.model.AdScriptIdentifier> adAncestryChain;

    private final java.util.Optional<java.lang.String> rootScriptFilterlistRule;

    public AdAncestry(java.util.List<org.openqa.selenium.devtools.v147.audits.model.AdScriptIdentifier> adAncestryChain, java.util.Optional<java.lang.String> rootScriptFilterlistRule) {
        this.adAncestryChain = java.util.Objects.requireNonNull(adAncestryChain, "adAncestryChain is required");
        this.rootScriptFilterlistRule = rootScriptFilterlistRule;
    }

    /**
     * The ad-script in the stack when the offending script was loaded. This is
     * recursive down to the root script that was tagged due to the filterlist
     * rule.
     */
    public java.util.List<org.openqa.selenium.devtools.v147.audits.model.AdScriptIdentifier> getAdAncestryChain() {
        return adAncestryChain;
    }

    /**
     * The filterlist rule that caused the root (last) script in
     * `adAncestry` to be ad-tagged.
     */
    public java.util.Optional<java.lang.String> getRootScriptFilterlistRule() {
        return rootScriptFilterlistRule;
    }

    private static AdAncestry fromJson(JsonInput input) {
        java.util.List<org.openqa.selenium.devtools.v147.audits.model.AdScriptIdentifier> adAncestryChain = null;
        java.util.Optional<java.lang.String> rootScriptFilterlistRule = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "adAncestryChain":
                    adAncestryChain = input.readArray(org.openqa.selenium.devtools.v147.audits.model.AdScriptIdentifier.class);
                    break;
                case "rootScriptFilterlistRule":
                    rootScriptFilterlistRule = java.util.Optional.ofNullable(input.nextString());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new AdAncestry(adAncestryChain, rootScriptFilterlistRule);
    }
}
