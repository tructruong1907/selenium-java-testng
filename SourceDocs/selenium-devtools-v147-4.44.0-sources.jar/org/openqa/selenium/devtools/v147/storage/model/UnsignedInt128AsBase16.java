package org.openqa.selenium.devtools.v147.storage.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

@org.openqa.selenium.Beta()
public class UnsignedInt128AsBase16 {

    private final java.lang.String unsignedInt128AsBase16;

    public UnsignedInt128AsBase16(java.lang.String unsignedInt128AsBase16) {
        this.unsignedInt128AsBase16 = java.util.Objects.requireNonNull(unsignedInt128AsBase16, "Missing value for UnsignedInt128AsBase16");
    }

    private static UnsignedInt128AsBase16 fromJson(JsonInput input) {
        return new UnsignedInt128AsBase16(input.nextString());
    }

    public String toJson() {
        return unsignedInt128AsBase16.toString();
    }

    public String toString() {
        return unsignedInt128AsBase16.toString();
    }
}
