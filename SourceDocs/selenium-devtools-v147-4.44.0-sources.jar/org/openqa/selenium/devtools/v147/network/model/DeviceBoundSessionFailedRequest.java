package org.openqa.selenium.devtools.v147.network.model;

import org.openqa.selenium.Beta;
import org.openqa.selenium.json.JsonInput;

/**
 * Details about a failed device bound session network request.
 */
@org.openqa.selenium.Beta()
public class DeviceBoundSessionFailedRequest {

    private final java.lang.String requestUrl;

    private final java.util.Optional<java.lang.String> netError;

    private final java.util.Optional<java.lang.Integer> responseError;

    private final java.util.Optional<java.lang.String> responseErrorBody;

    public DeviceBoundSessionFailedRequest(java.lang.String requestUrl, java.util.Optional<java.lang.String> netError, java.util.Optional<java.lang.Integer> responseError, java.util.Optional<java.lang.String> responseErrorBody) {
        this.requestUrl = java.util.Objects.requireNonNull(requestUrl, "requestUrl is required");
        this.netError = netError;
        this.responseError = responseError;
        this.responseErrorBody = responseErrorBody;
    }

    /**
     * The failed request URL.
     */
    public java.lang.String getRequestUrl() {
        return requestUrl;
    }

    /**
     * The net error of the response if it was not OK.
     */
    public java.util.Optional<java.lang.String> getNetError() {
        return netError;
    }

    /**
     * The response code if the net error was OK and the response code was not
     * 200.
     */
    public java.util.Optional<java.lang.Integer> getResponseError() {
        return responseError;
    }

    /**
     * The body of the response if the net error was OK, the response code was
     * not 200, and the response body was not empty.
     */
    public java.util.Optional<java.lang.String> getResponseErrorBody() {
        return responseErrorBody;
    }

    private static DeviceBoundSessionFailedRequest fromJson(JsonInput input) {
        java.lang.String requestUrl = null;
        java.util.Optional<java.lang.String> netError = java.util.Optional.empty();
        java.util.Optional<java.lang.Integer> responseError = java.util.Optional.empty();
        java.util.Optional<java.lang.String> responseErrorBody = java.util.Optional.empty();
        input.beginObject();
        while (input.hasNext()) {
            switch(input.nextName()) {
                case "requestUrl":
                    requestUrl = input.nextString();
                    break;
                case "netError":
                    netError = java.util.Optional.ofNullable(input.nextString());
                    break;
                case "responseError":
                    responseError = java.util.Optional.ofNullable(input.nextNumber().intValue());
                    break;
                case "responseErrorBody":
                    responseErrorBody = java.util.Optional.ofNullable(input.nextString());
                    break;
                default:
                    input.skipValue();
                    break;
            }
        }
        input.endObject();
        return new DeviceBoundSessionFailedRequest(requestUrl, netError, responseError, responseErrorBody);
    }
}
